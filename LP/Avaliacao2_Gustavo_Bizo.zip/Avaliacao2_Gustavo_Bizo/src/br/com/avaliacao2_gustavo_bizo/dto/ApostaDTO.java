/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.avaliacao2_gustavo_bizo.dto;
import java.math.BigDecimal;
import java.util.Date;
/**
 *
 * @author gbiz0
 */
public class ApostaDTO {
    private int id_aposta;
    private double val_aposta;

    public int getId_aposta() {
        return id_aposta;
    }

    public void setId_aposta(int id_aposta) {
        this.id_aposta = id_aposta;
    }

    public double getVal_aposta() {
        return val_aposta;
    }

    public void setVal_aposta(double val_aposta) {
        this.val_aposta = val_aposta;
    }

   
    
}
